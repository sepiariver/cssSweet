----------------------
cssSweet
----------------------
Version: 1.2.1-pl
Author: YJ Tso (@sepiariver)
Contact: yj@modx.com, info@sepiariver.com
----------------------

cssSweet is a suite of tools for processing CSS. It comes with several 
output modifiers to modify CSS values, and a plugin that writes 
processed CSS from the specified chunk to a flat CSS file.

Example Use Cases:
- Use system or context settings to store primary colors in a site's 
color scheme, then process all other color values relative to these,
so you can shift the entire color theme by modifying a few settings.
- Use in conjunction with ClientConfig to give site owners a nice UI
to manage CSS styles.
- Author MODX "themes" that are customizable by the end user.
- Use other MODX tags & placeholders in your CSS - limitless 
possibilities, "dynamic CSS" without performance penalty, because the
plugin writes the static CSS file on the Manager Clear Cache and
Chunk Save actions, not per request.
